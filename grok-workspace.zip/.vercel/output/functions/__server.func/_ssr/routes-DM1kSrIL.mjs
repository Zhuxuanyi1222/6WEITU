import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Shuffle, c as Moon, i as Sun, l as Minus, o as RotateCcw, r as Trash2, s as Plus, t as Upload, u as Download } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DM1kSrIL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function axisAngle(index, count, rotationDeg) {
	const step = Math.PI * 2 / count;
	return -Math.PI / 2 + rotationDeg * Math.PI / 180 + index * step;
}
function polar(cx, cy, r, angle) {
	return {
		x: cx + r * Math.cos(angle),
		y: cy + r * Math.sin(angle)
	};
}
function polygonPath(points) {
	if (points.length === 0) return "";
	return `M ${points.map((p) => `${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(" L ")} Z`;
}
/** Closed Catmull-Rom spline converted to cubic Beziers. */
function smoothClosedPath(points, tension = .85) {
	const n = points.length;
	if (n < 3) return polygonPath(points);
	let d = `M ${points[0].x.toFixed(2)} ${points[0].y.toFixed(2)}`;
	for (let i = 0; i < n; i++) {
		const p0 = points[(i - 1 + n) % n];
		const p1 = points[i];
		const p2 = points[(i + 1) % n];
		const p3 = points[(i + 2) % n];
		const cp1x = p1.x + (p2.x - p0.x) / 6 * tension;
		const cp1y = p1.y + (p2.y - p0.y) / 6 * tension;
		const cp2x = p2.x - (p3.x - p1.x) / 6 * tension;
		const cp2y = p2.y - (p3.y - p1.y) / 6 * tension;
		d += ` C ${cp1x.toFixed(2)} ${cp1y.toFixed(2)}, ${cp2x.toFixed(2)} ${cp2y.toFixed(2)}, ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`;
	}
	return `${d} Z`;
}
function projectOntoAxis(px, py, cx, cy, angle, maxR) {
	const vx = Math.cos(angle);
	const vy = Math.sin(angle);
	const proj = (px - cx) * vx + (py - cy) * vy;
	return Math.min(maxR, Math.max(0, proj));
}
function svgPoint(svg, clientX, clientY) {
	const ctm = svg.getScreenCTM();
	if (!ctm) {
		const rect = svg.getBoundingClientRect();
		const viewBox = svg.viewBox.baseVal;
		return {
			x: (clientX - rect.left) / rect.width * viewBox.width,
			y: (clientY - rect.top) / rect.height * viewBox.height
		};
	}
	const pt = svg.createSVGPoint();
	pt.x = clientX;
	pt.y = clientY;
	const loc = pt.matrixTransform(ctm.inverse());
	return {
		x: loc.x,
		y: loc.y
	};
}
function labelAnchor(angle) {
	const c = Math.cos(angle);
	const s = Math.sin(angle);
	let textAnchor = "middle";
	if (c > .35) textAnchor = "start";
	else if (c < -.35) textAnchor = "end";
	let dy = 0;
	if (s > .55) dy = 6;
	else if (s < -.55) dy = -2;
	return {
		textAnchor,
		dy
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}
var SWATCHES = [
	"var(--chart-1)",
	"var(--chart-2)",
	"var(--chart-3)",
	"var(--chart-4)",
	"var(--chart-5)"
];
var DEFAULT_STYLE = {
	gridLevels: 5,
	showLabels: true,
	showValues: true,
	showGrid: true,
	showAxisLines: true,
	filled: true,
	strokeWidth: 2,
	glow: true,
	rounded: false,
	breathe: true,
	rotation: 0,
	maxValue: 100
};
function makeAxes(labels) {
	return labels.map((label) => ({
		id: uid("ax"),
		label
	}));
}
function makeSeries(name, color, values, fillOpacity = .22) {
	return {
		id: uid("sr"),
		name,
		color,
		fillOpacity,
		values,
		visible: true
	};
}
var PRESETS = [
	{
		id: "ability",
		name: "能力模型",
		hint: "个人六维画像",
		build: () => {
			return {
				axes: makeAxes([
					"创造力",
					"执行力",
					"沟通协作",
					"学习成长",
					"领导力",
					"抗压韧性"
				]),
				series: [makeSeries("当前", "var(--chart-1)", [
					82,
					74,
					68,
					88,
					61,
					77
				])]
			};
		}
	},
	{
		id: "product",
		name: "产品体检",
		hint: "体验与品质",
		build: () => {
			return {
				axes: makeAxes([
					"易用性",
					"性能",
					"视觉",
					"稳定",
					"创新",
					"性价比"
				]),
				series: [makeSeries("本品", "var(--chart-1)", [
					86,
					71,
					90,
					78,
					64,
					73
				]), makeSeries("竞品", "var(--chart-2)", [
					72,
					84,
					66,
					81,
					58,
					80
				], .16)]
			};
		}
	},
	{
		id: "team",
		name: "团队雷达",
		hint: "职能覆盖",
		build: () => {
			return {
				axes: makeAxes([
					"工程",
					"产品",
					"设计",
					"增长",
					"销售",
					"文化"
				]),
				series: [makeSeries("现状", "var(--chart-1)", [
					80,
					62,
					71,
					54,
					48,
					76
				]), makeSeries("目标", "var(--chart-3)", [
					88,
					80,
					82,
					75,
					70,
					85
				], .12)]
			};
		}
	},
	{
		id: "body",
		name: "身心状态",
		hint: "训练与恢复",
		build: () => {
			return {
				axes: makeAxes([
					"力量",
					"耐力",
					"柔韧",
					"专注",
					"睡眠",
					"情绪"
				]),
				series: [makeSeries("本周", "var(--chart-1)", [
					70,
					64,
					58,
					73,
					51,
					66
				])]
			};
		}
	},
	{
		id: "character",
		name: "角色属性",
		hint: "攻防六维",
		build: () => {
			return {
				axes: makeAxes([
					"攻击",
					"防御",
					"速度",
					"智力",
					"幸运",
					"体力"
				]),
				series: [makeSeries("角色 A", "var(--chart-1)", [
					88,
					54,
					76,
					62,
					41,
					70
				]), makeSeries("角色 B", "var(--chart-4)", [
					61,
					82,
					48,
					79,
					55,
					86
				], .16)]
			};
		}
	},
	{
		id: "blank",
		name: "空白六维",
		hint: "从 50 开始",
		build: () => {
			return {
				axes: makeAxes([
					"维度一",
					"维度二",
					"维度三",
					"维度四",
					"维度五",
					"维度六"
				]),
				series: [makeSeries("系列 A", "var(--chart-1)", [
					50,
					50,
					50,
					50,
					50,
					50
				])]
			};
		}
	}
];
function defaultSnapshot() {
	const built = PRESETS[0].build();
	return {
		axes: built.axes,
		series: built.series,
		style: { ...DEFAULT_STYLE },
		theme: "dark",
		activeSeriesId: built.series[0].id
	};
}
var STORAGE_KEY = "hexa-radar-v1";
function clampValue(v, max) {
	return Math.min(max, Math.max(0, Math.round(v)));
}
function persistable(s) {
	return {
		axes: s.axes,
		series: s.series,
		style: s.style,
		theme: s.theme,
		activeSeriesId: s.activeSeriesId
	};
}
var persistReady = false;
function schedulePersist(state) {
	if (!persistReady || typeof window === "undefined") return;
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(persistable(state)));
	} catch {}
}
function normalize(raw) {
	const fallback = defaultSnapshot();
	const axes = Array.isArray(raw.axes) && raw.axes.length >= 3 ? raw.axes.slice(0, 12).map((a) => ({
		id: String(a.id || uid("ax")),
		label: String(a.label || "维度")
	})) : fallback.axes;
	const n = axes.length;
	const series = (Array.isArray(raw.series) && raw.series.length > 0 ? raw.series : fallback.series).slice(0, 3).map((s, i) => ({
		id: String(s.id || uid("sr")),
		name: String(s.name || `系列 ${i + 1}`),
		color: String(s.color || SWATCHES[i % SWATCHES.length]),
		fillOpacity: Number.isFinite(s.fillOpacity) ? s.fillOpacity : .22,
		visible: s.visible !== false,
		values: Array.from({ length: n }, (_, j) => clampValue(Number(s.values?.[j] ?? 50), 100))
	}));
	return {
		axes,
		series,
		style: {
			...fallback.style,
			...raw.style ?? {}
		},
		theme: raw.theme === "light" ? "light" : "dark",
		activeSeriesId: series.find((s) => s.id === raw.activeSeriesId)?.id ?? series[0].id
	};
}
var initial = defaultSnapshot();
var useRadarStore = create((set, get) => ({
	...initial,
	setAxisLabel: (id, label) => set((s) => ({ axes: s.axes.map((a) => a.id === id ? {
		...a,
		label
	} : a) })),
	setValue: (seriesId, axisIndex, value) => set((s) => ({ series: s.series.map((sr) => {
		if (sr.id !== seriesId) return sr;
		const values = sr.values.slice();
		values[axisIndex] = clampValue(value, s.style.maxValue);
		return {
			...sr,
			values
		};
	}) })),
	setSeriesName: (id, name) => set((s) => ({ series: s.series.map((sr) => sr.id === id ? {
		...sr,
		name
	} : sr) })),
	setSeriesColor: (id, color) => set((s) => ({ series: s.series.map((sr) => sr.id === id ? {
		...sr,
		color
	} : sr) })),
	setSeriesFill: (id, fillOpacity) => set((s) => ({ series: s.series.map((sr) => sr.id === id ? {
		...sr,
		fillOpacity
	} : sr) })),
	setSeriesVisible: (id, visible) => set((s) => ({ series: s.series.map((sr) => sr.id === id ? {
		...sr,
		visible
	} : sr) })),
	setActiveSeries: (id) => set({ activeSeriesId: id }),
	addSeries: () => set((s) => {
		if (s.series.length >= 3) return s;
		const i = s.series.length;
		const next = {
			id: uid("sr"),
			name: `对比 ${i}`,
			color: SWATCHES[i % SWATCHES.length],
			fillOpacity: .16,
			visible: true,
			values: s.axes.map(() => 50)
		};
		return {
			series: [...s.series, next],
			activeSeriesId: next.id
		};
	}),
	removeSeries: (id) => set((s) => {
		if (s.series.length <= 1) return s;
		const series = s.series.filter((sr) => sr.id !== id);
		return {
			series,
			activeSeriesId: s.activeSeriesId === id ? series[0].id : s.activeSeriesId
		};
	}),
	addAxis: () => set((s) => {
		if (s.axes.length >= 12) return s;
		const axis = {
			id: uid("ax"),
			label: `维度 ${s.axes.length + 1}`
		};
		return {
			axes: [...s.axes, axis],
			series: s.series.map((sr) => ({
				...sr,
				values: [...sr.values, 50]
			}))
		};
	}),
	removeAxis: (id) => set((s) => {
		if (s.axes.length <= 3) return s;
		const index = s.axes.findIndex((a) => a.id === id);
		if (index < 0) return s;
		return {
			axes: s.axes.filter((a) => a.id !== id),
			series: s.series.map((sr) => ({
				...sr,
				values: sr.values.filter((_, i) => i !== index)
			}))
		};
	}),
	patchStyle: (patch) => set((s) => ({ style: {
		...s.style,
		...patch
	} })),
	setTheme: (theme) => set({ theme }),
	applyPreset: (axes, series) => set({
		axes,
		series,
		activeSeriesId: series[0]?.id ?? ""
	}),
	randomize: () => set((s) => ({ series: s.series.map((sr) => sr.id === s.activeSeriesId ? {
		...sr,
		values: sr.values.map(() => 28 + Math.round(Math.random() * 64))
	} : sr) })),
	loadSnapshot: (snap) => set(normalize(snap)),
	toSnapshot: () => persistable(get())
}));
useRadarStore.subscribe((state) => schedulePersist(state));
function hydrateRadarStore() {
	if (typeof window === "undefined") return;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			useRadarStore.setState(normalize(parsed));
		}
	} catch {}
	persistReady = true;
	schedulePersist(useRadarStore.getState());
}
function keyOf(grid) {
	return grid.map((row) => row.join(",")).join("|");
}
function useSpringGrid(target, opts) {
	const [value, setValue] = (0, import_react.useState)(target);
	const valueRef = (0, import_react.useRef)(target);
	const velRef = (0, import_react.useRef)(target.map((row) => row.map(() => 0)));
	const targetRef = (0, import_react.useRef)(target);
	targetRef.current = target;
	(0, import_react.useEffect)(() => {
		const t = targetRef.current;
		if (!opts.enabled || opts.snap) {
			valueRef.current = t;
			velRef.current = t.map((row) => row.map(() => 0));
			setValue(t);
			return;
		}
		let raf = 0;
		const stiffness = .16;
		const damping = .72;
		const tick = () => {
			const nextTarget = targetRef.current;
			let cur = valueRef.current;
			let vel = velRef.current;
			if (cur.length !== nextTarget.length || cur[0]?.length !== nextTarget[0]?.length) {
				cur = nextTarget.map((row, i) => row.map((_, j) => cur[i]?.[j] ?? 0));
				vel = nextTarget.map((row, i) => row.map((_, j) => vel[i]?.[j] ?? 0));
			}
			let moving = false;
			const next = cur.map((row, i) => row.map((c, j) => {
				const d = (nextTarget[i]?.[j] ?? 0) - c;
				const v = ((vel[i]?.[j] ?? 0) + d * stiffness) * damping;
				if (!vel[i]) vel[i] = [];
				vel[i][j] = v;
				if (Math.abs(d) > .05 || Math.abs(v) > .05) moving = true;
				return c + v;
			}));
			valueRef.current = next;
			velRef.current = vel;
			setValue(next);
			if (moving) raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [
		keyOf(target),
		opts.enabled,
		opts.snap
	]);
	return value;
}
var VB = 540;
var CX = 270;
var CY = 270;
var MAX_R = 148;
var LABEL_R = 186;
function RadarCanvas({ svgRef }) {
	const axes = useRadarStore((s) => s.axes);
	const series = useRadarStore((s) => s.series);
	const style = useRadarStore((s) => s.style);
	const activeSeriesId = useRadarStore((s) => s.activeSeriesId);
	const setValue = useRadarStore((s) => s.setValue);
	const setActiveSeries = useRadarStore((s) => s.setActiveSeries);
	const [hover, setHover] = (0, import_react.useState)(null);
	const [dragging, setDragging] = (0, import_react.useState)(null);
	const [reduced, setReduced] = (0, import_react.useState)(false);
	const rawId = (0, import_react.useId)().replace(/:/g, "");
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		setReduced(mq.matches);
		const onChange = () => setReduced(mq.matches);
		mq.addEventListener("change", onChange);
		return () => mq.removeEventListener("change", onChange);
	}, []);
	const animated = useSpringGrid((0, import_react.useMemo)(() => series.map((s) => s.values), [series]), {
		enabled: !reduced,
		snap: Boolean(dragging) || reduced
	});
	const n = axes.length;
	const angles = (0, import_react.useMemo)(() => axes.map((_, i) => axisAngle(i, n, style.rotation)), [
		n,
		style.rotation,
		axes
	]);
	const gridPolys = (0, import_react.useMemo)(() => {
		return Array.from({ length: style.gridLevels }, (_, i) => {
			const r = (i + 1) / style.gridLevels * MAX_R;
			return polygonPath(angles.map((a) => polar(CX, CY, r, a)));
		});
	}, [angles, style.gridLevels]);
	const axisLines = (0, import_react.useMemo)(() => angles.map((a) => ({
		a,
		p: polar(CX, CY, MAX_R, a)
	})), [angles]);
	const seriesPaths = animated.map((values, si) => {
		const pts = values.map((v, i) => {
			return polar(CX, CY, v / style.maxValue * MAX_R, angles[i] ?? 0);
		});
		return {
			pts,
			d: style.rounded ? smoothClosedPath(pts) : polygonPath(pts),
			series: series[si]
		};
	});
	const dragRef = (0, import_react.useRef)(null);
	dragRef.current = dragging;
	(0, import_react.useEffect)(() => {
		if (!dragging) return;
		const onMove = (e) => {
			const svg = svgRef.current;
			const cur = dragRef.current;
			if (!svg || !cur) return;
			e.preventDefault();
			const pt = svgPoint(svg, e.clientX, e.clientY);
			const angle = angles[cur.axisIndex];
			if (angle === void 0) return;
			const r = projectOntoAxis(pt.x, pt.y, CX, CY, angle, MAX_R);
			setValue(cur.seriesId, cur.axisIndex, r / MAX_R * style.maxValue);
		};
		const onUp = () => setDragging(null);
		window.addEventListener("pointermove", onMove, { passive: false });
		window.addEventListener("pointerup", onUp);
		window.addEventListener("pointercancel", onUp);
		return () => {
			window.removeEventListener("pointermove", onMove);
			window.removeEventListener("pointerup", onUp);
			window.removeEventListener("pointercancel", onUp);
		};
	}, [
		dragging,
		angles,
		setValue,
		style.maxValue,
		svgRef
	]);
	const focus = dragging ?? hover;
	const focusAxis = focus ? axes[focus.axisIndex] : null;
	const focusSeries = focus ? series.find((s) => s.id === focus.seriesId) : null;
	const focusValue = focus ? Math.round(series.find((s) => s.id === focus.seriesId)?.values[focus.axisIndex] ?? 0) : null;
	const glowId = `glow-${rawId}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative aspect-square w-full",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			ref: svgRef,
			viewBox: `0 0 ${VB} ${VB}`,
			className: cn("h-full w-full touch-none select-none", dragging ? "cursor-grabbing" : "cursor-default"),
			role: "img",
			"aria-label": "六维雷达图",
			onPointerLeave: () => {
				if (!dragging) setHover(null);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
					id: glowId,
					x: "-40%",
					y: "-40%",
					width: "180%",
					height: "180%",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						stdDeviation: "6",
						result: "blur"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feMerge", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "blur" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "SourceGraphic" })] })]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: CX,
					cy: CY,
					r: 170,
					fill: "var(--surface)",
					className: "radar-plate"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: CX,
					cy: CY,
					r: 170,
					fill: "none",
					stroke: "var(--border-strong)",
					strokeWidth: "1"
				}),
				style.showGrid && gridPolys.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d,
					fill: "none",
					stroke: "var(--grid-line)",
					strokeWidth: i === gridPolys.length - 1 ? 1.2 : .8,
					className: "radar-grid-line",
					style: { animationDelay: `${i * 50}ms` }
				}, i)),
				style.showAxisLines && axisLines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: CX,
					y1: CY,
					x2: line.p.x,
					y2: line.p.y,
					stroke: focus?.axisIndex === i ? "var(--fg-muted)" : "var(--grid-line)",
					strokeWidth: focus?.axisIndex === i ? 1.4 : .9,
					className: "transition-[stroke] duration-[var(--motion-quick)]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: CX,
					y1: CY,
					x2: line.p.x,
					y2: line.p.y,
					stroke: "transparent",
					strokeWidth: "18",
					className: "cursor-pointer",
					"data-hide-export": "",
					onPointerDown: (e) => {
						e.preventDefault();
						const sid = activeSeriesId;
						const pt = svgRef.current ? svgPoint(svgRef.current, e.clientX, e.clientY) : null;
						if (pt) {
							const r = projectOntoAxis(pt.x, pt.y, CX, CY, line.a, MAX_R);
							setValue(sid, i, r / MAX_R * style.maxValue);
						}
						setDragging({
							seriesId: sid,
							axisIndex: i
						});
					},
					onPointerEnter: () => setHover({
						seriesId: activeSeriesId,
						axisIndex: i
					})
				})] }, axes[i]?.id ?? i)),
				seriesPaths.map(({ d, series: sr }, si) => {
					if (!sr.visible) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d,
						fill: style.filled ? sr.color : "none",
						stroke: "none",
						className: style.breathe && style.filled ? "radar-fill" : void 0,
						style: {
							fillOpacity: style.filled ? sr.fillOpacity : 0,
							["--fill-o"]: String(sr.fillOpacity),
							["--fill-o-hi"]: String(Math.min(.48, sr.fillOpacity * 1.45)),
							animationDelay: `${si * 120}ms`
						}
					}, `${sr.id}-fill`);
				}),
				seriesPaths.map(({ d, series: sr }) => {
					if (!sr.visible) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d,
						fill: "none",
						stroke: sr.color,
						strokeWidth: sr.id === activeSeriesId ? style.strokeWidth + .4 : style.strokeWidth,
						strokeLinejoin: "round",
						filter: style.glow && sr.id === activeSeriesId ? `url(#${glowId})` : void 0,
						className: "radar-stroke"
					}, `${sr.id}-stroke`);
				}),
				seriesPaths.map((entry, si) => ({
					...entry,
					si
				})).sort((a, b) => {
					return (a.series.id === activeSeriesId ? 1 : 0) - (b.series.id === activeSeriesId ? 1 : 0);
				}).map(({ pts, series: sr }) => {
					if (!sr.visible) return null;
					const active = sr.id === activeSeriesId;
					return pts.map((p, i) => {
						const isFocus = focus?.seriesId === sr.id && focus.axisIndex === i;
						const r = isFocus ? 7 : active ? 5 : 3.2;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: p.x,
								cy: p.y,
								r: r + 10,
								fill: "transparent",
								className: "cursor-grab",
								"data-hide-export": "",
								onPointerDown: (e) => {
									e.preventDefault();
									e.stopPropagation();
									setActiveSeries(sr.id);
									setDragging({
										seriesId: sr.id,
										axisIndex: i
									});
								},
								onPointerEnter: () => setHover({
									seriesId: sr.id,
									axisIndex: i
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: p.x,
								cy: p.y,
								r,
								fill: "var(--bg)",
								stroke: sr.color,
								strokeWidth: active ? 2.2 : 1.5,
								className: "pointer-events-none transition-[r] duration-[var(--motion-quick)] ease-[var(--ease-out)]"
							}),
							isFocus && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: p.x,
								cy: p.y,
								r: 2.2,
								fill: sr.color,
								className: "pointer-events-none"
							})
						] }, `${sr.id}-${axes[i]?.id ?? i}`);
					});
				}),
				style.showValues && seriesPaths.map(({ pts, series: sr }) => {
					if (sr.id !== activeSeriesId || !sr.visible) return null;
					return pts.map((p, i) => {
						const angle = angles[i] ?? 0;
						const tip = polar(CX, CY, Math.hypot(p.x - CX, p.y - CY) + 14, angle);
						const val = Math.round(animated[series.indexOf(sr)]?.[i] ?? 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: tip.x,
							y: tip.y,
							textAnchor: "middle",
							dominantBaseline: "middle",
							className: "radar-label pointer-events-none",
							fill: "var(--fg-muted)",
							fontSize: "11",
							fontFamily: "var(--font-sans)",
							style: { animationDelay: `${180 + i * 40}ms` },
							children: val
						}, `v-${sr.id}-${i}`);
					});
				}),
				style.showLabels && axes.map((axis, i) => {
					const angle = angles[i] ?? 0;
					const p = polar(CX, CY, LABEL_R, angle);
					const { textAnchor, dy } = labelAnchor(angle);
					const on = focus?.axisIndex === i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: p.x,
						y: p.y + dy,
						textAnchor,
						fill: on ? "var(--fg)" : "var(--fg-muted)",
						fontSize: "12",
						fontWeight: on ? 600 : 500,
						fontFamily: "var(--font-sans)",
						className: "radar-label pointer-events-none",
						style: { animationDelay: `${80 + i * 50}ms` },
						children: axis.label
					}, axis.id);
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-0 flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("flex flex-col items-center text-center transition-[opacity,filter,transform] duration-[var(--motion-fast)] ease-[var(--ease-out)]", focus ? "translate-y-0 opacity-100 blur-0" : "translate-y-0 opacity-100"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-lg leading-tight tracking-[var(--tracking-display)] text-fg",
					children: focusAxis ? focusAxis.label : "HEXA"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 text-xs tracking-wide text-muted tabular-nums",
					children: focus && focusSeries ? `${focusSeries.name}  ${focusValue}` : `${n} 维`
				})]
			})
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[transform,background-color,color,opacity,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			ghost: "bg-transparent text-fg hover:bg-elevated",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			subtle: "bg-elevated text-fg hover:bg-elevated/80",
			danger: "bg-danger/15 text-danger hover:bg-danger/25"
		},
		size: {
			default: "h-10 rounded-md px-3.5 text-sm",
			sm: "h-9 rounded-sm px-3 text-sm",
			lg: "h-11 rounded-md px-4 text-sm",
			icon: "size-10 rounded-md",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, static: isStatic, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), !isStatic && "active:not-disabled:scale-[0.96]", className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-10 w-full rounded-sm bg-elevated px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none transition-[box-shadow] duration-[var(--motion-quick)] placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-accent/60", className),
		...props
	});
}
function Separator({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "separator",
		className: cn("h-px w-full bg-border", className)
	});
}
function Slider({ className, trackClassName, rangeClassName, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: cn("relative h-1 w-full grow overflow-hidden rounded-full bg-elevated", trackClassName),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: cn("absolute h-full bg-accent", rangeClassName) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "relative block size-4 rounded-full bg-fg shadow-[var(--shadow-border)] after:absolute after:top-1/2 after:left-1/2 after:size-11 after:-translate-x-1/2 after:-translate-y-1/2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60" })]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-10 shrink-0 cursor-pointer items-center rounded-full bg-elevated shadow-[var(--shadow-border)] transition-[background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] data-[state=checked]:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-0.5 rounded-full bg-fg transition-transform duration-[var(--motion-fast)] ease-[var(--ease-out)] data-[state=checked]:translate-x-[18px] data-[state=checked]:bg-accent-fg" })
	});
}
function Section({ title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-8 items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xs font-medium tracking-widest text-muted uppercase",
				children: title
			}), action]
		}), children]
	});
}
function ToggleRow({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex h-11 items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-fg",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked,
			onCheckedChange: onChange
		})]
	});
}
function ControlPanel() {
	const axes = useRadarStore((s) => s.axes);
	const series = useRadarStore((s) => s.series);
	const style = useRadarStore((s) => s.style);
	const activeSeriesId = useRadarStore((s) => s.activeSeriesId);
	const setAxisLabel = useRadarStore((s) => s.setAxisLabel);
	const setValue = useRadarStore((s) => s.setValue);
	const setSeriesName = useRadarStore((s) => s.setSeriesName);
	const setSeriesColor = useRadarStore((s) => s.setSeriesColor);
	const setSeriesFill = useRadarStore((s) => s.setSeriesFill);
	const setSeriesVisible = useRadarStore((s) => s.setSeriesVisible);
	const setActiveSeries = useRadarStore((s) => s.setActiveSeries);
	const addSeries = useRadarStore((s) => s.addSeries);
	const removeSeries = useRadarStore((s) => s.removeSeries);
	const addAxis = useRadarStore((s) => s.addAxis);
	const removeAxis = useRadarStore((s) => s.removeAxis);
	const patchStyle = useRadarStore((s) => s.patchStyle);
	const applyPreset = useRadarStore((s) => s.applyPreset);
	const active = series.find((s) => s.id === activeSeriesId) ?? series[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "预设",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							const built = p.build();
							applyPreset(built.axes, built.series);
						},
						className: "h-9 rounded-full px-3 text-sm text-fg shadow-[var(--shadow-border)] transition-[background-color,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:bg-elevated active:scale-[0.96]",
						children: p.name
					}, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "系列",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: addSeries,
					disabled: series.length >= 3,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "对比"]
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: series.map((sr) => {
						const on = sr.id === active.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActiveSeries(sr.id),
							className: cn("flex h-11 items-center gap-3 rounded-md px-3 text-left transition-[background-color,box-shadow] duration-[var(--motion-quick)]", on ? "bg-elevated shadow-[var(--shadow-border)]" : "hover:bg-elevated/60"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-2.5 rounded-full",
									style: { background: sr.color }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate text-sm text-fg",
									children: sr.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									role: "presentation",
									className: cn("text-xs tabular-nums text-muted", sr.visible ? "opacity-100" : "opacity-40"),
									children: sr.visible ? "显示" : "隐藏"
								})
							]
						}, sr.id);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 rounded-sm bg-elevated p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: active.name,
								onChange: (e) => setSeriesName(active.id, e.target.value),
								"aria-label": "系列名称"
							}), series.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								size: "icon",
								onClick: () => removeSeries(active.id),
								"aria-label": "删除系列",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [SWATCHES.map((sw) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `颜色 ${sw}`,
								onClick: () => setSeriesColor(active.id, sw),
								className: cn("size-7 rounded-full transition-transform duration-[var(--motion-quick)] active:scale-[0.96]", active.color === sw ? "ring-2 ring-fg ring-offset-2 ring-offset-elevated" : "opacity-80 hover:opacity-100"),
								style: { background: sw }
							}, sw)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "relative size-7 overflow-hidden rounded-full shadow-[var(--shadow-border)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "自定义颜色"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "color",
									className: "absolute top-1/2 left-1/2 size-10 -translate-x-1/2 -translate-y-1/2 scale-150 cursor-pointer border-0 p-0",
									value: active.color.startsWith("#") ? active.color : "#8ec8c4",
									onChange: (e) => setSeriesColor(active.id, e.target.value)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
							label: "显示此系列",
							checked: active.visible,
							onChange: (v) => setSeriesVisible(active.id, v)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "填充浓度"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums text-fg",
								children: [Math.round(active.fillOpacity * 100), "%"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 0,
							max: 50,
							step: 1,
							value: [Math.round(active.fillOpacity * 100)],
							onValueChange: ([v]) => setSeriesFill(active.id, (v ?? 0) / 100),
							rangeClassName: "bg-fg/70"
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "维度",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							onClick: () => {
								const last = axes[axes.length - 1];
								if (last) removeAxis(last.id);
							},
							disabled: axes.length <= 3,
							"aria-label": "减少维度",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-6 text-center text-xs tabular-nums text-muted",
							children: axes.length
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							onClick: addAxis,
							disabled: axes.length >= 12,
							"aria-label": "增加维度",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
						})
					]
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-3",
					children: axes.map((axis, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: axis.label,
								onChange: (e) => setAxisLabel(axis.id, e.target.value),
								className: "h-10 min-w-0 flex-1",
								"aria-label": `维度名称 ${i + 1}`
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								className: "shrink-0 text-muted hover:text-danger",
								onClick: () => removeAxis(axis.id),
								disabled: axes.length <= 3,
								"aria-label": `删除 ${axis.label}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								className: "min-w-0 flex-1",
								min: 0,
								max: style.maxValue,
								step: 1,
								value: [active.values[i] ?? 0],
								onValueChange: ([v]) => setValue(active.id, i, v ?? 0),
								rangeClassName: "bg-accent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-8 text-right text-sm tabular-nums text-fg",
								children: active.values[i] ?? 0
							})]
						})]
					}, axis.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "外观",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "网格",
								checked: style.showGrid,
								onChange: (v) => patchStyle({ showGrid: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "轴线",
								checked: style.showAxisLines,
								onChange: (v) => patchStyle({ showAxisLines: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "标签",
								checked: style.showLabels,
								onChange: (v) => patchStyle({ showLabels: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "数值",
								checked: style.showValues,
								onChange: (v) => patchStyle({ showValues: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "填充",
								checked: style.filled,
								onChange: (v) => patchStyle({ filled: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "光晕",
								checked: style.glow,
								onChange: (v) => patchStyle({ glow: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "圆角造型",
								checked: style.rounded,
								onChange: (v) => patchStyle({ rounded: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "呼吸",
								checked: style.breathe,
								onChange: (v) => patchStyle({ breathe: v })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "网格层数"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-fg",
							children: style.gridLevels
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 3,
						max: 8,
						step: 1,
						value: [style.gridLevels],
						onValueChange: ([v]) => patchStyle({ gridLevels: v ?? 5 })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "描边"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-fg",
							children: style.strokeWidth
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 1,
						max: 5,
						step: .5,
						value: [style.strokeWidth],
						onValueChange: ([v]) => patchStyle({ strokeWidth: v ?? 2 })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "旋转"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-fg",
							children: [style.rotation, "°"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 0,
						max: 360,
						step: 1,
						value: [style.rotation],
						onValueChange: ([v]) => patchStyle({ rotation: v ?? 0 })
					})] })
				]
			})
		]
	});
}
function resolveCssVars(svgMarkup) {
	const cs = getComputedStyle(document.documentElement);
	return svgMarkup.replace(/var\((--[a-z0-9-]+)\)/gi, (full, name) => {
		return cs.getPropertyValue(name).trim() || full;
	});
}
function serializeSvg(svg) {
	const clone = svg.cloneNode(true);
	clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
	clone.querySelectorAll("[data-hide-export]").forEach((el) => el.remove());
	const bg = document.createElementNS("http://www.w3.org/2000/svg", "rect");
	bg.setAttribute("width", "100%");
	bg.setAttribute("height", "100%");
	bg.setAttribute("fill", getComputedStyle(document.documentElement).getPropertyValue("--bg").trim() || "#09090b");
	clone.insertBefore(bg, clone.firstChild);
	return resolveCssVars(new XMLSerializer().serializeToString(clone));
}
function download(filename, blob) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function exportSvg(svg, filename = "hexa-radar.svg") {
	const markup = serializeSvg(svg);
	download(filename, new Blob([markup], { type: "image/svg+xml;charset=utf-8" }));
}
function exportPng(svg, filename = "hexa-radar.png") {
	const markup = serializeSvg(svg);
	const blob = new Blob([markup], { type: "image/svg+xml;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const img = new Image();
	img.onload = () => {
		const canvas = document.createElement("canvas");
		canvas.width = 1600;
		canvas.height = 1600;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.drawImage(img, 0, 0, 1600, 1600);
		canvas.toBlob((out) => {
			if (out) download(filename, out);
			URL.revokeObjectURL(url);
		}, "image/png");
	};
	img.onerror = () => URL.revokeObjectURL(url);
	img.src = url;
}
async function copyJson(data) {
	await navigator.clipboard.writeText(JSON.stringify(data, null, 2));
}
function AppShell() {
	const svgRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const theme = useRadarStore((s) => s.theme);
	const setTheme = useRadarStore((s) => s.setTheme);
	const randomize = useRadarStore((s) => s.randomize);
	const loadSnapshot = useRadarStore((s) => s.loadSnapshot);
	const toSnapshot = useRadarStore((s) => s.toSnapshot);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [exportOpen, setExportOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		hydrateRadarStore();
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = theme;
	}, [theme]);
	(0, import_react.useEffect)(() => {
		if (!exportOpen) return;
		const close = () => setExportOpen(false);
		window.addEventListener("click", close);
		return () => window.removeEventListener("click", close);
	}, [exportOpen]);
	(0, import_react.useEffect)(() => {
		if (!notice) return;
		const t = window.setTimeout(() => setNotice(null), 1800);
		return () => window.clearTimeout(t);
	}, [notice]);
	const replayIntro = () => {
		const snap = toSnapshot();
		const zeroed = {
			...snap,
			series: snap.series.map((s) => ({
				...s,
				values: s.values.map(() => 0)
			}))
		};
		loadSnapshot(zeroed);
		window.requestAnimationFrame(() => {
			window.requestAnimationFrame(() => loadSnapshot(snap));
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-6xl flex-col gap-6 px-5 py-5 pb-20 sm:px-8 lg:px-10 lg:py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mr-auto min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Radar Studio"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl leading-none tracking-[var(--tracking-display)] text-balance sm:text-4xl",
						children: "HEXA"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "subtle",
							size: "sm",
							onClick: randomize,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, {}), "随机"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "subtle",
							size: "sm",
							onClick: replayIntro,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "回放"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "subtle",
								size: "sm",
								onClick: (e) => {
									e.stopPropagation();
									setExportOpen((v) => !v);
								},
								"aria-expanded": exportOpen,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "导出"]
							}), exportOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute right-0 z-20 mt-2 w-44 rounded-lg bg-surface p-1.5 shadow-[var(--shadow-border)]",
								onClick: (e) => e.stopPropagation(),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "flex h-10 w-full items-center rounded-sm px-3 text-sm text-fg hover:bg-elevated",
										onClick: () => {
											if (svgRef.current) exportPng(svgRef.current);
											setExportOpen(false);
											setNotice("已导出 PNG");
										},
										children: "导出 PNG"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "flex h-10 w-full items-center rounded-sm px-3 text-sm text-fg hover:bg-elevated",
										onClick: () => {
											if (svgRef.current) exportSvg(svgRef.current);
											setExportOpen(false);
											setNotice("已导出 SVG");
										},
										children: "导出 SVG"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "flex h-10 w-full items-center rounded-sm px-3 text-sm text-fg hover:bg-elevated",
										onClick: async () => {
											await copyJson(toSnapshot());
											setExportOpen(false);
											setNotice("配置已复制");
										},
										children: "复制 JSON"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => fileRef.current?.click(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), "导入"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json,.json",
							className: "hidden",
							onChange: async (e) => {
								const file = e.target.files?.[0];
								e.target.value = "";
								if (!file) return;
								try {
									const text = await file.text();
									loadSnapshot(JSON.parse(text));
									setNotice("已导入配置");
								} catch {
									setNotice("导入失败");
								}
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
							"aria-label": theme === "dark" ? "切换浅色" : "切换深色",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative size-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: cnIcon(theme === "light") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: cnIcon(theme === "dark") })]
							})
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-6 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-w-0 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-8 lg:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadarCanvas, { svgRef }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 px-2 text-center text-sm text-muted",
						children: "拖动顶点或点击轴线调整数值，切换预设可看到形态过渡。"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "min-w-0 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5 lg:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlPanel, {})
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `pointer-events-none fixed bottom-6 left-1/2 z-30 -translate-x-1/2 rounded-full bg-elevated px-4 py-2 text-sm text-fg shadow-[var(--shadow-border)] transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-out)] ${notice ? "translate-y-0 opacity-100 blur-0" : "translate-y-2 opacity-0 blur-[2px]"}`,
			role: "status",
			children: notice ?? " "
		})]
	});
}
function cnIcon(active) {
	return ["absolute inset-0 size-4 transition-[opacity,transform,filter] duration-[var(--motion-fast)] ease-[var(--ease-out)]", active ? "scale-100 opacity-100 blur-0" : "scale-[0.25] opacity-0 blur-[4px]"].join(" ");
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
