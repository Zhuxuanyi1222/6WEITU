//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CLcEPbzM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CDHqK_Id.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CDHqK_Id.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DT1Zgvlc.js"]
	}
} });
//#endregion
export { tsrStartManifest };
